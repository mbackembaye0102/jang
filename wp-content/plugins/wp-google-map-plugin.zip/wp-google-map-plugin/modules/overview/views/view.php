<?php
/**
 * Plugin Overviews.
 * @package Maps
 * @author Flipper Code <flippercode>
 **/

$form  = new WPGMP_Template();
$productOverviewObj = $form->product_overview();
